import os
import arcpy
import sys
from arcpy import env

arcpy.env.overwriteOutput = True

# Get the value of the input parameters
infc = arcpy.GetParameterAsText(0) 
CellWidth = arcpy.GetParameterAsText(1)
CellHeight = arcpy.GetParameterAsText(2) 
sort_method = arcpy.GetParameterAsText(3) 
Dist = arcpy.GetParameterAsText(4) 
measure = arcpy.GetParameterAsText(5) 
Result = arcpy.GetParameterAsText(6) 

des = os.path.dirname(Result)
# set workspace environment
env.workspace = des

labels = 'LABELS'
geometryType = 'POLYGON'

#Calculate buffer distance
s1 = Dist.split()[0]
s = float(s1)

extent = arcpy.Describe(infc).extent
if extent.XMin == extent.XMax and  extent.YMin == extent.YMax:
    arcpy.AddError("\nInput feature class has same origin Coordinate and Y Axis Coordinate.\n")
    arcpy.AddWarning("\nSelect a different polygon feature class.\n\n")
    quit()
elif s <= 0:
    arcpy.AddError("\nPlease enter positive non-zero value for social distance.\n\n")
    quit()

file = os.path.join(des,"test.shp")
file1 = os.path.join(des,"test_label.shp")
# Fetch each feature from the cursor and examine the extent properties
try:
    for row in arcpy.da.SearchCursor(infc, ['SHAPE@']):
            extent = row[0].extent   
            fishnet = arcpy.CreateFishnet_management(file,
                                           str(extent.XMin) + " " + str(extent.YMin),
                                           str(extent.XMin) + " " + str(extent.YMax),
                                           CellWidth, CellHeight,
                                           "",
                                           "",
                                           str(extent.XMax) + " " + str(extent.YMax),
                                           labels,
                                           infc,
                                           geometryType)
    Fish_sorted = os.path.join(des, "Fishnet.shp")
    label_sorted = os.path.join(des, "Label.shp")
    arcpy.Sort_management(fishnet, Fish_sorted, [["Shape", "ASCENDING"]],sort_method)
    arcpy.Sort_management(file1, label_sorted, [["Shape", "ASCENDING"]],sort_method)
    field2 = "Id"
    cursor = arcpy.UpdateCursor(Fish_sorted)
    for row in cursor:
        row.setValue(field2, row.getValue("FID"))
        cursor.updateRow(row)
    field3 = "Id"
    l_cursor = arcpy.UpdateCursor(label_sorted)
    for i in l_cursor:
        
        i.setValue(field3, i.getValue("FID"))
        l_cursor.updateRow(i)  
except:
    msgs = "\nError Info:\n\n" + str(sys.exc_info()[1])
    arcpy.AddError(msgs)
    quit()
    
arcpy.Delete_management("test.shp")
arcpy.Delete_management("test_label.shp")

try:
    if measure == "Center":
        Distance = s - float(CellWidth)
        arcpy.AddMessage("\n...Measuring social distance from cell center.\n")
    else:
        Distance = Dist
        arcpy.AddMessage("\n...Measuring social distance from cell boundary.\n")
except:
    msg = "Failed to calculate buffer distance."
    arcpy.AddError(msg)
    msgs = "\nError Info:\n\n" + str(sys.exc_info()[1])
    arcpy.AddError(msgs)
    quit()

Buf_temp = os.path.join(des,"Buf.shp")  
Clip_temp = os.path.join(des,"Clip.shp")
#Empty list for Fishnet Cell Ids and Clipped cell Ids
FID = []
Fc = []
flag = 0
cursor1 = arcpy.SearchCursor(Fish_sorted)	
try:
    for row in cursor1:
        if flag == 0:
            flag =1
            FID.append(row.getValue("Id"))
            n = arcpy.Buffer_analysis(row.Shape, Buf_temp, Distance, "OUTSIDE_ONLY", "", "NONE")
            arcpy.Clip_analysis(label_sorted, n, Clip_temp)
            arcpy.Clip_analysis(Fish_sorted, row.Shape, "FishnetClip.shp",'')
            arcpy.CopyFeatures_management("FishnetClip.shp", Result)
            clip_curs = arcpy.SearchCursor(Clip_temp)
            for record in clip_curs:
                Fc.append(record.getValue("Id"))
        else:
            if row.getValue("Id") in Fc:
                continue      
            else:
                FID.append(row.getValue("Id"))       
                n = arcpy.Buffer_analysis(row.Shape, Buf_temp, Distance, "OUTSIDE_ONLY", "", "NONE")
                arcpy.Clip_analysis(label_sorted, n, Clip_temp)
                arcpy.Clip_analysis(Fish_sorted, row.Shape, "FishnetClip.shp",'')
                arcpy.Append_management("FishnetClip.shp", Result, "TEST")
                clip_curs = arcpy.SearchCursor(Clip_temp)
                for record in clip_curs:
                    Fc.append(record.getValue("Id"))
except:
    msg = "...An error occured while buffering fishnet cells!"
    arcpy.AddError(msg)
    msgs = "\nError Info:\n\n" + str(sys.exc_info()[1])
    arcpy.AddError(msgs)
    quit()

arcpy.Delete_management(Buf_temp)
arcpy.Delete_management(Clip_temp)
arcpy.Delete_management("FishnetClip.shp")
arcpy.Delete_management(Fish_sorted)
arcpy.Delete_management(label_sorted)
x = len(FID)
arcpy.AddMessage("...Revised Seating Capacity is {0}".format(x))                                      
arcpy.AddMessage("\n...Process Completed!!\n")